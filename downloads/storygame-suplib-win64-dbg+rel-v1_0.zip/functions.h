#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#define WAIT _getch();
#define SLEP(x) Sleep((x));
#define SHOW(x) slowOutput((x), 20, true);
#define PRNT(x) cout << (x);
// 屏幕清空
#define CLEAR    "\033[2J\033[0;0H"
// 光标定位
#define LLINE    "\033[1A"
#define NLINE    "\033[1B"
// 字体属性
#define COLOR    "\033[0m"
#define BOLD     "\033[1m"
#define NBOLD    "\033[22m"
#define UNDLI    "\033[4m"
#define NUNDLI   "\033[24m"
// 字体颜色
#define FBLACK   "\033[30m"
#define FRED     "\033[31m"
#define FGREEN   "\033[32m"
#define FYELLOW  "\033[33m"
#define FBLUE    "\033[34m"
#define FMAGENTA "\033[35m"
#define FCYAN    "\033[36m"
#define FWHITE   "\033[37m"
#define FDEFAULT "\033[39m"
#define BBLACK   "\033[40m"
#define BRED     "\033[41m"
#define BGREEN   "\033[42m"
#define BYELLOW  "\033[43m"
#define BBLUE    "\033[44m"
#define BMAGENTA "\033[45m"
#define BCYAN    "\033[46m"
#define BWHITE   "\033[47m"
#define BDEFAULT "\033[49m"

#include <string>
#include <conio.h>
#include <iostream>
#include <windows.h>

namespace Game
{
	// ANSI 转义序列启动（必须）
	void enableANSI() noexcept;
	
	// 清空屏幕
	const char screenClear[] = "\033[2J";
	
	// 光标移动
	void moveCursor(SHORT, SHORT);
	
	// 修改标题
	void editTitle(const std::string&);
	
	// 更改窗口宽度
	void editWinLength(const int);
	
	// 缓慢输出
	void slowOutput(const std::string&, const unsigned int, const bool = 1);
	
	// 选择器
	char selector(char&, const std::string&);
}

#endif
