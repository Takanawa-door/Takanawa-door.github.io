#include "functions.h"

// 启动 ANSI
void Game::enableANSI() noexcept
{
	HANDLE hOut; DWORD mode;
	hOut = GetStdHandle(STD_OUTPUT_HANDLE);
	GetConsoleMode(hOut, &mode);
	mode |= ENABLE_PROCESSED_OUTPUT | ENABLE_VIRTUAL_TERMINAL_PROCESSING;
	SetConsoleMode(hOut, mode);
}

// 光标移动
void Game::moveCursor(SHORT x, SHORT y)
{
	std::cout << "\033[" << y << ';' << x << 'H';
}

// 标题修改
void Game::editTitle(const std::string& s)
{
	std::cout << "\033]0;" << s << '\x07';
}

// 更改窗口宽度
void Game::editWinLength(const int x)
{
	switch (x)
	{
	case 132:
		std::cout << "\033[?3h"; break;
	case 80:
		std::cout << "\033[?3l"; break;
	}
}

// 缓慢输出
void Game::slowOutput(const std::string& s, const unsigned int sleepTime, const bool canSkip)
{
	// 跳过用的东西
	bool flag = false;
	
	for (auto c : s)
	{
		std::cout << c;
		if (_kbhit())
		{
			char i = _getch();
			if (i == ' ' || i == '\r')
			{
				flag = true;
			}
		}
		
		if (!flag)
		{
			Sleep(sleepTime);
		}
	}
}

// 选择器
char Game::selector(char& to, const std::string& items)
{
	if (items.empty()) return 0;
	
	char ans, get;
	ans = get = items[0];
	std::cout << ans;
	
	while (true)
	{
		get = _getch();
		
		if (get == '\r') break;
		
		for (auto c : items)
		{
			if (_tolower(c) == _tolower(get))
			{
				ans = c;
				std::cout << '\b' << ans;
				break;
			}
		}
	}
	
	return to = ans;
}
