/*
 gamelib/ansichar.hxx
 提供 ANSI 转义序列启用的相关函数，还有转义序列宏定义
 */

#pragma once

#include <windows.h>

// 关于转义序列的宏定义
// 屏幕清空
#define CLEAR    "\033[2J\033[0;0H"
// 光标定位
#define LLINE    "\033[1A"
#define NLINE    "\033[1B"
// 字体属性
#define COLOR    "\033[0m"
#define BOLD     "\033[1m"
#define NBOLD    "\033[22m"
#define UNDLI    "\033[4m"
#define NUNDLI   "\033[24m"
// 字体颜色
// F 为 Foreground
// B 为 Background
#define FBLACK   "\033[30m"
#define FRED     "\033[31m"
#define FGREEN   "\033[32m"
#define FYELLOW  "\033[33m"
#define FBLUE    "\033[34m"
#define FMAGENTA "\033[35m"
#define FCYAN    "\033[36m"
#define FWHITE   "\033[37m"
#define FDEFAULT "\033[39m"
#define BBLACK   "\033[40m"
#define BRED     "\033[41m"
#define BGREEN   "\033[42m"
#define BYELLOW  "\033[43m"
#define BBLUE    "\033[44m"
#define BMAGENTA "\033[45m"
#define BCYAN    "\033[46m"
#define BWHITE   "\033[47m"
#define BDEFAULT "\033[49m"

namespace GameLib
{
    void enableANSI(HANDLE hOut);
}
