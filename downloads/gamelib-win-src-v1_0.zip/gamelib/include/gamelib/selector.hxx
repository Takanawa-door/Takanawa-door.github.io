/*
 gamelib/selector.hxx
 提供项目选择器。
 */

#pragma once

#include <string>
#include <vector>
#include <conio.h>
#include <iostream>
#include <windows.h>

namespace GameLib
{
    // 选项选择器
    const size_t selector(const std::vector<std::string>& options, HANDLE hOut,
            CONSOLE_SCREEN_BUFFER_INFOEX& csbi, CONSOLE_CURSOR_INFO& cci,
            const std::string& split = "\n") noexcept;
}
