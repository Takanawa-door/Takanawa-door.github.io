/*
 gamelib/clearscreen.hxx
 提供文字移动函数与清空屏幕的函数。
 */

#pragma once

#include <windows.h>

namespace GameLib
{
    // 移动文本
    int moveText(HANDLE hOut, const CONSOLE_SCREEN_BUFFER_INFOEX& csbi,
            const SMALL_RECT& area, const COORD& dest) noexcept;
    // 屏幕清空
    int clearScreen(HANDLE hOut, CONSOLE_SCREEN_BUFFER_INFOEX& csbi) noexcept;
}
