#include <gamelib/ansichar.hxx>

void GameLib::enableANSI(HANDLE hOut)
{
    DWORD outMode;
    GetConsoleMode(hOut, &outMode);
    outMode |= ENABLE_VIRTUAL_TERMINAL_PROCESSING | ENABLE_PROCESSED_OUTPUT;
    SetConsoleMode(hOut, outMode);
}
