#include <gamelib/selector.hxx>

// 选项选择器
const size_t GameLib::selector(const std::vector<std::string>& options,
        HANDLE hOut, CONSOLE_SCREEN_BUFFER_INFOEX& csbi,
        CONSOLE_CURSOR_INFO& cci, const std::string& split) noexcept
{
	if (options.empty())
	{
		return -1;
	}

	// 当前选中项
	size_t selected = 0;
	// 获取的字符
	char getChar;
	// 选中项颜色 & 默认颜色
	DWORD selectedColor, defaultColor;
	// 记录每一个选项占用的区域
	std::vector<SMALL_RECT> optionArea;
	optionArea.resize(options.size());

	GetConsoleScreenBufferInfoEx(hOut, &csbi);
	defaultColor = csbi.wAttributes;
	selectedColor = defaultColor % 16 * 16 + defaultColor / 16;
	
	GetConsoleCursorInfo(hOut, &cci);
	bool oldVis = cci.bVisible;
	cci.bVisible = false;
	SetConsoleCursorInfo(hOut, &cci);

	// 输出选项
	while (true)
	{
		// 输出文本
		for (size_t i = 0; i < options.size(); ++i)
		{
			// 记录坐标
			GetConsoleScreenBufferInfoEx(hOut, &csbi);
			optionArea.at(i).Left = csbi.dwCursorPosition.X;
			optionArea.at(i).Top  = csbi.dwCursorPosition.Y;

			if (i == selected)
			{
				// 反转颜色以突出选中项
				SetConsoleTextAttribute(hOut, selectedColor);
			}
			std::cout << options.at(i) << split;
			if (i == selected)
			{
				SetConsoleTextAttribute(hOut, defaultColor);
			}

			GetConsoleScreenBufferInfoEx(hOut, &csbi);
			optionArea.at(i).Right  = csbi.dwCursorPosition.X;
			optionArea.at(i).Bottom = csbi.dwCursorPosition.Y;
		}

		SetConsoleCursorPosition(hOut, { optionArea.at(selected).Left,
                optionArea.at(selected).Top });

		getChar = _getch();

		SetConsoleCursorPosition(hOut, { optionArea.at(0).Left,
                optionArea.at(0).Top });

		if (getChar == '\n' || getChar == '\r' || getChar == 3)
		{
			break;
		}

		switch (getChar)
		{
        case 'b':
        case 'B':
		case 'h':
		case 'H':
		case 'k':
		case 'K':
			// 切换到上一个
			selected = (selected > 0 ? selected - 1 : 0);
			break;

        case 'w':
        case 'W':
		case 'l':
		case 'L':
		case 'j':
		case 'J':
			// 切换到上一个
			selected = (++selected < options.size() ? selected : options.size() - 1);
			break;

		default:
			break;
		}
	}

	auto& lastOptAre = optionArea.at(optionArea.size() - 1);
	SetConsoleCursorPosition(hOut, { lastOptAre.Left, lastOptAre.Bottom });
	cci.bVisible = oldVis;
	SetConsoleCursorInfo(hOut, &cci);
	
	return selected;
}
