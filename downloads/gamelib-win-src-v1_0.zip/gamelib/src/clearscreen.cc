#include <gamelib/clearscreen.hxx>

// 移动文本
int GameLib::moveText(HANDLE hOut, const CONSOLE_SCREEN_BUFFER_INFOEX& csbi,
        const SMALL_RECT& area, const COORD& dest) noexcept
{
    CHAR_INFO ci;
    ci.Char.AsciiChar = ' ';
    ci.Attributes = csbi.wAttributes;
    return ScrollConsoleScreenBufferA(hOut, &area, nullptr, dest, &ci);
}

// 屏幕清空
int GameLib::clearScreen(HANDLE hOut, CONSOLE_SCREEN_BUFFER_INFOEX& csbi) noexcept
{
    auto res = moveText(hOut, csbi, { 0, 0, csbi.dwSize.X, csbi.dwSize.Y }, {
            0, SHORT(0 - csbi.dwSize.Y)});
    res |= SetConsoleCursorPosition(hOut, { 0, 0 });
    return res;
}
