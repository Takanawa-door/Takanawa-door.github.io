// 封装音乐接口

#pragma once

#include <windows.h>
#include <mmsystem.h>
#include <format>
#include <string>
#pragma comment(lib, "winmm.h")

// 音乐播放器类
class Music
{
public:
    // mci 指定的别名；文件路径
    std::string name, path;
    // 指定播放音量
    int vol;
    // 音频长度
    int len;
    // 指定是否循环播放
    bool doRepeat;
    // 是否暂停了
    bool isPause;
    // Mci 参数
    // 返回字符串
    static const int RETURN_STRING_LEN = 1024;
    char returnString[RETURN_STRING_LEN];

    MCIERROR load();          // 加载文件
    MCIERROR unload();        // 关闭文件
    MCIERROR play(const int); // 播放音乐
    MCIERROR pause();         // 暂停播放
    MCIERROR volume();        // 设置当前音量
    MCIERROR seek(const int); // 移动播放位置
    int      where();         // 获取播放位置
    int      length();        // 获取音频长度

    // 构造与构析函数
    Music();
    ~Music();
};
