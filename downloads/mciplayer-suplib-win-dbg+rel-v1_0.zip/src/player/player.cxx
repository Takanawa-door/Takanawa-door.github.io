#include "../../include/mciplayer/player.h"

// 音乐类实现
// 构造与构析函数
Music::Music()
{
    name     = "";
    path     = "";
    vol      = 1000;
    doRepeat = false;
    isPause  = false;
}

Music::~Music()
{
    unload();
}

// 加载音乐
MCIERROR Music::load()
{
    return mciSendStringA(std::format("open \"{}\" alias {}", path, name).c_str(), returnString, RETURN_STRING_LEN, nullptr);
}

// 关闭音乐
MCIERROR Music::unload()
{
    return mciSendStringA(std::format("close {}", name).c_str(), returnString, RETURN_STRING_LEN, nullptr);
}

// 播放音乐
MCIERROR Music::play(const int from)
{
    std::string cmd;
    cmd = std::format("play {} from {}", name, from);

    // 循环加上 repeat
    if (doRepeat)
    {
        cmd += " repeat";
    }

    auto status = mciSendStringA(cmd.c_str(), returnString, RETURN_STRING_LEN, nullptr);
    if (status == 0) isPause = false;
    return status;
}

// 暂停音乐
MCIERROR Music::pause()
{
    MCIERROR status;

    if (isPause)
    {
        status = mciSendStringA(std::format("pause {}", name).c_str(), returnString, RETURN_STRING_LEN, nullptr);
    }
    else
    {
        status = mciSendStringA(std::format("resume {}", name).c_str(), returnString, RETURN_STRING_LEN, nullptr);
    }

    if (status == 0)
    {
        isPause = !isPause;
    }
    return status;
}

// 设置当前音量
MCIERROR Music::volume()
{
    return mciSendStringA(std::format("setaudio {} volume to {}", name, vol).c_str(), returnString, RETURN_STRING_LEN, nullptr);
}

// 移动播放位置
MCIERROR Music::seek(const int pos)
{
    return mciSendStringA(std::format("seek {} to {}", name, pos).c_str(), returnString, RETURN_STRING_LEN, nullptr);
}

// 获取当前播放位置
int Music::where()
{
    auto status = mciSendStringA(std::format("status {} position", name).c_str(), returnString, RETURN_STRING_LEN, nullptr);
    if (status != 0)
    {
        return -status;
    }
    return len = atoi(returnString);
}

// 获取音频长度
int Music::length()
{
    auto status = mciSendStringA(std::format("status {} length", name).c_str(), returnString, RETURN_STRING_LEN, nullptr);
    if (status != 0)
    {
        return -status;
    }
    return len = atoi(returnString);
}
